/* Function Prototypes */
/** Initialize the Saic module */
void vfnInit_Saic(void);