/* Function Prototypes */
/** Initialization of the selected channel of the Pad Configuration Register from the SIU */
void vfnSelect_Analog_Pin(uint8_t u8Channel);

/** Selection of ADC channels to be used */
void vfnSelect_Adc_Channel(uint8_t u8Channel);

/** Initialization of the ADC module */
void vfnInit_Adc(void);

/**
  \brief	Get ADC scan
  \param  	u8Channel: The channel used for ADC.u8MaximumValue: The maximum possible value for the result 
  \return	An integer from 0 to u8MaximumValue proportional to the ADC scan
*/
uint16_t u16Read_Adc(uint8_t u8Channel, uint16_t u16MaximumValue);
