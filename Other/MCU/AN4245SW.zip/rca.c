#include "MPC5604B_0M27V_0102.h"
#include "Driver_MPC5604B.h"
#include "Setup.h"
#include "Driver_ADC.h"
#include "Driver_PWM.h"         
#include "Driver_IPWM.h"
#include "Driver_SAIC.h" 
#include "rca.h" 


/*	uint32_t Pixel[128];
	uint32_t picture[256];
	uint32_t centers[50];

	int32_t reset=0;
  	int32_t reset2=0;
  	int32_t i=0;
  	int32_t cont=0;
  	int32_t min=1023;
  	int32_t pos=0;
  	int32_t pos2=0;
  	int32_t pos3=0;
  	int32_t center=0;
  	int32_t center2=0;
  	int32_t center3=0;
  	int32_t done=0;
  	int32_t linewidth=0;  
  	int32_t treshold=50;
  	int32_t pix=0;
  	int32_t cont2=0;
  	int32_t prom=0;
  	int32_t prom2=0;
  	int32_t start=0;	*/
  	
  	
int32_t vertical_sync(int32_t treshold)
{
	int32_t valid[2];
	valid[0]=u16Read_Adc(0,1023);
	valid[1]=u16Read_Adc(0,1023);
	if(valid[0]<treshold && valid[1]<treshold)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/*

void read_cam(void)
{
		reset=u16Read_Adc(0,1023);
		reset2=u16Read_Adc(0,1023);
			if(	reset<60 && reset2<60)								//confirma pulso de sincronia
			{
				i=0;
				while(i<45)											//cantidad de pixeles leidos
				{
					Pixel[i]=u16Read_Adc(0,1023);					//lee el pixel actual
					if(i>7)
					{
						prom+=Pixel[i];
						if(Pixel[i]<min)
						{
							min=Pixel[i];							//guarda pixel actual en matriz
							pos=i;
						}
					}
					i++;
				}
				min=1023;
				prom/=36;											//saca el nivel de luz de la imagen
				i=0;
				pos2=pos;
				pos3=pos;
				while(Pixel[pos2]<min+treshold && pos2<45)
				{
					pos2++;
				}
				while(Pixel[pos3]<min+treshold && pos3>7)
				{
					pos3--;
				}
				linewidth=pos2-pos3;
				center=(pos2+pos3)/2;
				picture[start]=center;
				start++;
			}
			min=1023;
}

uint32_t read_lines(int32_t linea, int32_t linea2)       //valores entre 5 y 160
{
if(	reset<60 && reset2<60)								//confirma pulso de sincronia
	{
		if(prom<300 || start>160)							//verifica que no haya sido pulso de sincronizacion
		{													//de nueva imagen y que no hayan pasado mas de 
			prom2=0;										//160 lineas
			done=linea;
			pix=0;
			while(done<linea2)									//
			{
				if(picture[done]<45 && picture[done]>7)
				{
				prom2+=picture[done];
				pix++;
				}
				done++;
			}
			prom2=prom2/pix;
			prom2*=(3*30);
			start=0;
			cont=0;
		}
	}
	return prom2;
}*/