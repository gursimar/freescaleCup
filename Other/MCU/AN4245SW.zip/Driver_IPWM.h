/* Function Prototypes */
/** Initialize the Ipwm module */
void vfnInit_Ipwm(void);
