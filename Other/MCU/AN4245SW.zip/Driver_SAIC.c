#include "MPC5604B_0M27V_0102.h"
#include "Driver_MPC5604B.h"
#include "Driver_EMIOS.h"

#define RISING_EDGE 	0
#define FALLING_EDGE 	1



void vfnInit_Saic(void)
{
    //vfnInit_Emios_0();                  /* Sets Emios0 on*/
    
	//vfnInit_Emios_0_Mcb(0,20000); 		/* Set channel 0 as MCB  */
  	vfnInit_Emios_0_Saic(3,EMIOS_0_3,RISING_EDGE);	/* Set channel 1 as SAIC */
}

