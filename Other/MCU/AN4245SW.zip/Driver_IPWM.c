#include "MPC5604B_0M27V_0102.h"
#include "Driver_MPC5604B.h"
#include "Driver_EMIOS.h"



void vfnInit_Ipwm(void)
{

    vfnInit_Emios_0_Mcb(0,20000); 
    vfnInit_Emios_0_Ipwm(5,EMIOS_0_5,1);	/* Set channel 1 as IPWM */		//AO1
 


}

